package com.horizonbank.accounts.service;

import com.horizonbank.accounts.api.dto.TransferRequest;
import com.horizonbank.accounts.domain.BusinessException;
import com.horizonbank.accounts.domain.ErrorCode;
import com.horizonbank.accounts.events.TransferCommitted;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.List;
import java.util.UUID;

@Service
public class TransferService {

    private static final BigDecimal DAILY_LIMIT = new BigDecimal("500000.00");
    private static final ZoneId IST = ZoneId.of("Asia/Kolkata");

    private final JdbcClient jdbc;
    private final ApplicationEventPublisher events;

    public TransferService(JdbcClient jdbc, ApplicationEventPublisher events) {
        this.jdbc = jdbc;
        this.events = events;
    }

    public record Locked(long id, String number, BigDecimal balance, String status) {}
    public record TransferRow(UUID id, String referenceNo, OffsetDateTime createdAt) {}

    @Transactional
    public TransferResult transfer(TransferRequest req, String idemKey) {
        try {
            jdbc.sql("SET LOCAL lock_timeout = '3s'").update();
        } catch (Exception e) {
            throw new BusinessException(ErrorCode.SERVICE_BUSY, "Could not acquire lock in time");
        }
        
        List<Locked> rows;
        try {
            rows = jdbc.sql("""
                    SELECT account_id, account_number, balance, status
                    FROM account
                    WHERE account_number IN (:from, :to)
                    ORDER BY account_id
                    FOR UPDATE""")
                    .param("from", req.fromAccountNumber())
                    .param("to", req.toAccountNumber())
                    .query((rs, n) -> new Locked(rs.getLong(1), rs.getString(2), rs.getBigDecimal(3), rs.getString(4)))
                    .list();
        } catch (DataAccessException e) {
            if (e.getMessage() != null && e.getMessage().contains("55P03")) { // lock_not_available
                throw new BusinessException(ErrorCode.SERVICE_BUSY);
            }
            if (e.getMessage() != null && e.getMessage().contains("40P01")) { // deadlock_detected
                throw new BusinessException(ErrorCode.SERVICE_BUSY);
            }
            throw e;
        }

        Locked from = find(rows, req.fromAccountNumber());
        Locked to = find(rows, req.toAccountNumber());

        if (!"ACTIVE".equals(from.status()) || !"ACTIVE".equals(to.status()))
            throw new BusinessException(ErrorCode.ACCOUNT_NOT_ACTIVE);
            
        BigDecimal amount = new BigDecimal(req.amount());
        if (from.balance().compareTo(amount) < 0)
            throw new BusinessException(ErrorCode.INSUFFICIENT_FUNDS);

        BigDecimal sentToday = jdbc.sql("""
                SELECT COALESCE(SUM(amount), 0) FROM fund_transfer
                WHERE from_account_id = :id AND status = 'COMPLETED' AND created_at >= :since""")
                .param("id", from.id())
                .param("since", LocalDate.now(IST).atStartOfDay(IST).toOffsetDateTime())
                .query(BigDecimal.class).single();

        if (sentToday.add(amount).compareTo(DAILY_LIMIT) > 0)
            throw new BusinessException(ErrorCode.DAILY_LIMIT_EXCEEDED);

        TransferRow t;
        try {
            t = jdbc.sql("""
                INSERT INTO fund_transfer (idempotency_key, from_account_id, to_account_id, amount, remarks)
                VALUES (:key, :from, :to, :amount, :remarks)
                RETURNING transfer_id, reference_no, created_at""")
                .param("key", idemKey)
                .param("from", from.id())
                .param("to", to.id())
                .param("amount", amount)
                .param("remarks", req.remarks())
                .query((rs, n) -> new TransferRow(rs.getObject(1, UUID.class), rs.getString(2), rs.getObject(3, OffsetDateTime.class)))
                .single();
        } catch (DataAccessException e) {
            String msg = e.getMessage() != null ? e.getMessage() : "";
            if (msg.contains("uq_transfer_idempotency")) {
                throw new BusinessException(ErrorCode.DUPLICATE_ACCOUNT_TYPE); // Caught by idempotency service
            }
            throw e;
        }

        BigDecimal fromBal = move(from.id(), amount.negate());
        BigDecimal toBal = move(to.id(), amount);

        String suffix = (req.remarks() == null || req.remarks().isEmpty()) ? "" : " - " + req.remarks();
        ledger(from.id(), t.id(), "DEBIT", amount, fromBal, "Transfer to " + to.number() + suffix);
        ledger(to.id(), t.id(), "CREDIT", amount, toBal, "Transfer from " + from.number() + suffix);

        TransferResult result = new TransferResult(t.id(), t.referenceNo(), t.createdAt(),
                from.number(), to.number(), amount, req.remarks(), fromBal, toBal);
        events.publishEvent(new TransferCommitted(result));
        return result;
    }

    private BigDecimal move(long accountId, BigDecimal delta) {
        return jdbc.sql("""
                UPDATE account SET balance = balance + :delta, updated_at = now()
                WHERE account_id = :id
                RETURNING balance""")
                .param("delta", delta)
                .param("id", accountId)
                .query(BigDecimal.class).single();
    }

    private void ledger(long accountId, UUID transferId, String type, BigDecimal amount, BigDecimal balanceAfter, String description) {
        jdbc.sql("""
                INSERT INTO account_transaction
                (account_id, transfer_id, txn_type, amount, balance_after, description)
                VALUES (:acc, :tid, :type, :amount, :after, :descr)""")
                .param("acc", accountId).param("tid", transferId).param("type", type)
                .param("amount", amount).param("after", balanceAfter).param("descr", description)
                .update();
    }

    private static Locked find(List<Locked> rows, String number) {
        return rows.stream().filter(r -> r.number().equals(number)).findFirst()
                .orElseThrow(() -> new BusinessException(ErrorCode.ACCOUNT_NOT_FOUND, "Account not found: " + number));
    }
}
