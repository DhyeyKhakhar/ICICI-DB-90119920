package com.horizonbank.accounts.service;

import com.horizonbank.accounts.api.dto.AccountOpenResponse;

public record AccountResult(AccountOpenResponse response, boolean cached) {}
