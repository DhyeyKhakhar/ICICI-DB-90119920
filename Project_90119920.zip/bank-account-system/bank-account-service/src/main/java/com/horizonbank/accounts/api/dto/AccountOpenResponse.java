package com.horizonbank.accounts.api.dto;

import java.time.OffsetDateTime;

public record AccountOpenResponse(
    String accountNumber,
    long customerId,
    String customerName,
    boolean newCustomer,
    String accountType,
    String currency,
    String balance,
    String status,
    OffsetDateTime openedAt
) {}
