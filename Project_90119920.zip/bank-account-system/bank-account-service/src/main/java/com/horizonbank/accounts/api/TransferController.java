package com.horizonbank.accounts.api;

import com.horizonbank.accounts.api.dto.TransferRequest;
import com.horizonbank.accounts.api.dto.TransferResponse;
import com.horizonbank.accounts.domain.BusinessException;
import com.horizonbank.accounts.domain.ErrorCode;
import com.horizonbank.accounts.service.IdempotencyService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.regex.Pattern;

@RestController
@RequestMapping("/api/v1/transfers")
public class TransferController {

    private final IdempotencyService idempotencyService;
    private static final Pattern IDEMPOTENCY_KEY_PATTERN = Pattern.compile("^[A-Za-z0-9\\-_]{1,64}$");

    public TransferController(IdempotencyService idempotencyService) {
        this.idempotencyService = idempotencyService;
    }

    @PostMapping
    public ResponseEntity<TransferResponse> transfer(
            @RequestHeader(value = "Idempotency-Key", required = false) String idempotencyKey,
            @Valid @RequestBody TransferRequest request) {

        if (idempotencyKey == null || !IDEMPOTENCY_KEY_PATTERN.matcher(idempotencyKey).matches()) {
            throw new BusinessException(ErrorCode.MISSING_IDEMPOTENCY_KEY, "Idempotency-Key header missing or malformed");
        }
        if (request.fromAccountNumber().equals(request.toAccountNumber())) {
            throw new BusinessException(ErrorCode.SAME_ACCOUNT_TRANSFER, "Sender and receiver accounts must differ");
        }

        var result = idempotencyService.execute(idempotencyKey, request);
        
        var builder = ResponseEntity.status(201)
                .location(URI.create("/api/v1/transfers/" + result.response().referenceNo()));
        if (result.replayed()) {
            builder.header("Idempotent-Replayed", "true");
        }
        return builder.body(result.response());
    }

    @GetMapping("/{referenceNo}")
    public ResponseEntity<TransferResponse> getTransfer(@PathVariable String referenceNo) {
        var tr = idempotencyService.getTransfer(referenceNo);
        return ResponseEntity.ok(tr);
    }
}
