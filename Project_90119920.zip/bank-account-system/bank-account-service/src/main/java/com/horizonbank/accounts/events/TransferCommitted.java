package com.horizonbank.accounts.events;
import com.horizonbank.accounts.service.TransferResult;
public record TransferCommitted(TransferResult result) {}
