package com.horizonbank.accounts.api.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

public record AccountOpenRequest(
    @Valid @NotNull
    CustomerDTO customer,

    @NotBlank
    @Pattern(regexp = "^(SAVINGS|CURRENT)$")
    String accountType,

    @NotBlank
    String initialDeposit
) {}
