package com.horizonbank.accounts.api.dto;

public record TransactionDTO(
    long txnId,
    String txnTime,
    String type,
    String amount,
    String balanceAfter,
    String description,
    String referenceNo
) {}
