package com.horizonbank.accounts.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.horizonbank.accounts.api.dto.TransferRequest;
import com.horizonbank.accounts.api.dto.TransferResponse;
import com.horizonbank.accounts.domain.BusinessException;
import com.horizonbank.accounts.domain.ErrorCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.stereotype.Service;

import java.time.Duration;

@Service
public class IdempotencyService {
    private static final Logger log = LoggerFactory.getLogger(IdempotencyService.class);
    private final StringRedisTemplate redis;
    private final TransferService transferService;
    private final ObjectMapper mapper;
    private final JdbcClient jdbc;

    public IdempotencyService(StringRedisTemplate redis, TransferService transferService, ObjectMapper mapper, JdbcClient jdbc) {
        this.redis = redis;
        this.transferService = transferService;
        this.mapper = mapper;
        this.jdbc = jdbc;
    }

    public IdempotentResult execute(String idemKey, TransferRequest request) {
        String key = "bank:idem:" + idemKey;
        Boolean claimed;
        try {
            claimed = redis.opsForValue().setIfAbsent(key, "PENDING", Duration.ofHours(24));
        } catch (RuntimeException e) {
            log.warn("Redis unavailable - relying on uq_transfer_idempotency", e);
            return doTransfer(request, idemKey);
        }

        if (Boolean.FALSE.equals(claimed)) {
            String stored = redis.opsForValue().get(key);
            if ("PENDING".equals(stored)) {
                throw new BusinessException(ErrorCode.REQUEST_IN_PROGRESS);
            }
            if (stored != null && stored.startsWith("ERR:")) {
                throw new BusinessException(ErrorCode.valueOf(stored.substring(4)));
            }
            try {
                return new IdempotentResult(mapper.readValue(stored, TransferResponse.class), true);
            } catch (Exception e) {
                throw new RuntimeException("Failed to parse stored response", e);
            }
        }

        TransferResponse response = null;
        try {
            response = doTransfer(request, idemKey).response();
        } catch (BusinessException e) {
            try {
                redis.opsForValue().setIfPresent(key, "ERR:" + e.getErrorCode().name(), Duration.ofHours(24));
            } catch (Exception ex) {}
            throw e;
        } catch (RuntimeException e) {
            redis.delete(key);
            throw e;
        }

        try {
            redis.opsForValue().setIfPresent(key, mapper.writeValueAsString(response), Duration.ofHours(24));
        } catch (Exception e) {
            // ignore
        }
        return new IdempotentResult(response, false);
    }

    private IdempotentResult doTransfer(TransferRequest request, String idemKey) {
        try {
            TransferResult tr = transferService.transfer(request, idemKey);
            TransferResponse response = new TransferResponse(
                    tr.transferId().toString(), tr.referenceNo(), "COMPLETED",
                    tr.fromAccountNumber(), tr.toAccountNumber(), tr.amount().toPlainString(),
                    "INR", tr.remarks(), tr.fromBalanceAfter().toPlainString(), tr.createdAt()
            );
            return new IdempotentResult(response, false);
        } catch (BusinessException e) {
            if (e.getErrorCode() == ErrorCode.DUPLICATE_ACCOUNT_TYPE) {
                var existing = jdbc.sql("SELECT transfer_id, reference_no, amount, remarks, created_at FROM fund_transfer WHERE idempotency_key = ?")
                        .param(idemKey)
                        .query((rs, n) -> new TransferResponse(
                                rs.getString(1), rs.getString(2), "COMPLETED",
                                request.fromAccountNumber(), request.toAccountNumber(),
                                rs.getBigDecimal(3).toPlainString(), "INR", rs.getString(4),
                                null, rs.getObject(5, java.time.OffsetDateTime.class)
                        )).optional().orElseThrow(() -> e);
                return new IdempotentResult(existing, true);
            }
            throw e;
        }
    }

    public TransferResponse getTransfer(String referenceNo) {
        return jdbc.sql("SELECT transfer_id, reference_no, from_account_id, to_account_id, amount, remarks, created_at FROM fund_transfer WHERE reference_no = ?")
                .param(referenceNo)
                .query((rs, n) -> {
                    String fromAcc = jdbc.sql("SELECT account_number FROM account WHERE account_id = ?").param(rs.getLong(3)).query(String.class).single();
                    String toAcc = jdbc.sql("SELECT account_number FROM account WHERE account_id = ?").param(rs.getLong(4)).query(String.class).single();
                    return new TransferResponse(
                        rs.getString(1), rs.getString(2), "COMPLETED",
                        fromAcc, toAcc,
                        rs.getBigDecimal(5).toPlainString(), "INR", rs.getString(6),
                        null, rs.getObject(7, java.time.OffsetDateTime.class)
                    );
                }).optional().orElseThrow(() -> new BusinessException(ErrorCode.TRANSFER_NOT_FOUND));
    }
}
