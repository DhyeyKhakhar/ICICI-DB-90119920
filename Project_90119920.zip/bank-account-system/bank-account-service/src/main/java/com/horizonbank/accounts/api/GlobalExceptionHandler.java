package com.horizonbank.accounts.api;

import com.horizonbank.accounts.domain.BusinessException;
import com.horizonbank.accounts.domain.ErrorCode;
import org.slf4j.MDC;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.net.URI;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ProblemDetail> handleValidation(MethodArgumentNotValidException ex) {
        ProblemDetail pd = ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST, "Validation failed");
        pd.setType(URI.create("https://api.horizonbank.example/problems/validation-error"));
        pd.setTitle("Request validation failed");
        pd.setProperty("errorCode", ErrorCode.VALIDATION_ERROR.name());
        pd.setProperty("correlationId", MDC.get("correlationId"));
        pd.setProperty("timestamp", OffsetDateTime.now(ZoneId.of("Asia/Kolkata")).toString());
        
        List<Map<String, String>> errors = ex.getBindingResult().getFieldErrors().stream()
                .map(err -> Map.of("field", err.getField(), "message", err.getDefaultMessage()))
                .collect(Collectors.toList());
        pd.setProperty("errors", errors);
        
        return ResponseEntity.badRequest().body(pd);
    }

    @ExceptionHandler(BusinessException.class)
    public ResponseEntity<ProblemDetail> handleBusiness(BusinessException ex) {
        HttpStatus status = switch (ex.getErrorCode()) {
            case VALIDATION_ERROR -> HttpStatus.BAD_REQUEST;
            case ACCOUNT_NOT_FOUND, TRANSFER_NOT_FOUND -> HttpStatus.NOT_FOUND;
            case DUPLICATE_ACCOUNT_TYPE, CUSTOMER_CONFLICT, REQUEST_IN_PROGRESS -> HttpStatus.CONFLICT;
            case SAME_ACCOUNT_TRANSFER, ACCOUNT_NOT_ACTIVE, INSUFFICIENT_FUNDS, DAILY_LIMIT_EXCEEDED -> HttpStatus.UNPROCESSABLE_ENTITY;
            case SERVICE_BUSY, SERVICE_UNAVAILABLE -> HttpStatus.SERVICE_UNAVAILABLE;
            default -> HttpStatus.INTERNAL_SERVER_ERROR;
        };

        ProblemDetail pd = ProblemDetail.forStatusAndDetail(status, ex.getMessage());
        pd.setType(URI.create("https://api.horizonbank.example/problems/business-error"));
        pd.setTitle("Business rule violation");
        pd.setProperty("errorCode", ex.getErrorCode().name());
        pd.setProperty("correlationId", MDC.get("correlationId"));
        pd.setProperty("timestamp", OffsetDateTime.now(ZoneId.of("Asia/Kolkata")).toString());
        
        if (status == HttpStatus.SERVICE_UNAVAILABLE) {
            return ResponseEntity.status(status).header("Retry-After", "1").body(pd);
        }
        
        return ResponseEntity.status(status).body(pd);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ProblemDetail> handleAll(Exception ex) {
        ProblemDetail pd = ProblemDetail.forStatusAndDetail(HttpStatus.INTERNAL_SERVER_ERROR, "Internal error");
        pd.setType(URI.create("https://api.horizonbank.example/problems/internal-error"));
        pd.setTitle("Internal server error");
        pd.setProperty("errorCode", ErrorCode.INTERNAL_ERROR.name());
        pd.setProperty("correlationId", MDC.get("correlationId"));
        pd.setProperty("timestamp", OffsetDateTime.now(ZoneId.of("Asia/Kolkata")).toString());
        
        return ResponseEntity.internalServerError().body(pd);
    }
}
