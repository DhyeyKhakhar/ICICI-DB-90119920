package com.horizonbank.accounts.events;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.horizonbank.accounts.api.dto.CustomerDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.Map;
import java.util.UUID;

@Component
public class EventPublisher {
    private static final Logger log = LoggerFactory.getLogger(EventPublisher.class);
    private final KafkaTemplate<String, String> kafka;
    private final ObjectMapper mapper;

    public EventPublisher(KafkaTemplate<String, String> kafka, ObjectMapper mapper) {
        this.kafka = kafka;
        this.mapper = mapper;
    }

    public void accountOpened(String accountNumber, long customerId, CustomerDTO c, String type, String deposit) {
        Map<String, Object> data = Map.of(
                "accountNumber", accountNumber,
                "customerId", customerId,
                "customerName", c.fullName(),
                "accountType", type,
                "currency", "INR",
                "initialDeposit", deposit,
                "phone", c.phone(),
                "email", c.email()
        );
        send("bank.account.opened.v1", accountNumber, envelope("AccountOpened", data));
    }
    
    public void transferCompleted(com.horizonbank.accounts.service.TransferResult r) {
        Map<String, Object> data = Map.of(
                "transferId", r.transferId().toString(),
                "referenceNo", r.referenceNo(),
                "fromAccountNumber", r.fromAccountNumber(),
                "toAccountNumber", r.toAccountNumber(),
                "amount", r.amount().toPlainString(),
                "currency", "INR",
                "fromBalanceAfter", r.fromBalanceAfter().toPlainString(),
                "toBalanceAfter", r.toBalanceAfter().toPlainString(),
                "remarks", r.remarks() != null ? r.remarks() : ""
        );
        send("bank.transfer.completed.v1", r.fromAccountNumber(), envelope("TransferCompleted", data));
    }

    private Map<String, Object> envelope(String type, Map<String, Object> data) {
        return Map.of(
                "eventId", UUID.randomUUID().toString(),
                "eventType", type,
                "eventVersion", 1,
                "occurredAt", OffsetDateTime.now(ZoneId.of("Asia/Kolkata")).toString(),
                "source", "bank-account-service",
                "correlationId", org.slf4j.MDC.get("correlationId") == null ? UUID.randomUUID().toString() : org.slf4j.MDC.get("correlationId"),
                "data", data
        );
    }

    private void send(String topic, String key, Map<String, Object> event) {
        try {
            String json = mapper.writeValueAsString(event);
            kafka.send(topic, key, json).whenComplete((res, ex) -> {
                if (ex != null) {
                    log.error("Kafka publish failed - re-publish manually: {}", json, ex);
                }
            });
        } catch (JsonProcessingException e) {
            log.error("Failed to serialize event", e);
        }
    }
}
