package com.horizonbank.accounts.api.dto;

import java.util.List;

public record StatementResponse(
    String accountNumber,
    String customerName,
    String currency,
    String fromDate,
    String toDate,
    String openingBalance,
    String closingBalance,
    String totalCredits,
    String totalDebits,
    int page,
    int size,
    long totalElements,
    int totalPages,
    List<TransactionDTO> transactions
) {}
