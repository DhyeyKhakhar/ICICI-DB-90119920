package com.horizonbank.accounts.api.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

public record TransferRequest(
    @NotBlank
    @Pattern(regexp = "^\\d{12}$", message = "must be 12 digits")
    String fromAccountNumber,

    @NotBlank
    @Pattern(regexp = "^\\d{12}$", message = "must be 12 digits")
    String toAccountNumber,

    @NotBlank
    @Pattern(regexp = "^\\d+(\\.\\d{1,2})?$", message = "must have at most 2 decimal places")
    String amount,

    String remarks
) {}
