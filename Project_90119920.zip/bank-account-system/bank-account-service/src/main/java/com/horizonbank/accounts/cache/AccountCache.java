package com.horizonbank.accounts.cache;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.horizonbank.accounts.api.dto.AccountOpenResponse;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.util.Map;

@Component
public class AccountCache {
    private final StringRedisTemplate redis;
    private final ObjectMapper mapper;

    public AccountCache(StringRedisTemplate redis, ObjectMapper mapper) {
        this.redis = redis;
        this.mapper = mapper;
    }

    public AccountOpenResponse get(String accountNumber) {
        try {
            Map<Object, Object> hash = redis.opsForHash().entries("bank:account:" + accountNumber);
            if (hash.isEmpty()) return null;
            return mapper.convertValue(hash, AccountOpenResponse.class);
        } catch (Exception e) {
            return null; // NFR-04
        }
    }

    public void put(String accountNumber, AccountOpenResponse response) {
        try {
            String key = "bank:account:" + accountNumber;
            Map map = mapper.convertValue(response, Map.class);
            // Convert everything to string for redis hash
            map.replaceAll((k, v) -> v != null ? v.toString() : null);
            redis.opsForHash().putAll(key, map);
            redis.expire(key, Duration.ofMinutes(10));
        } catch (Exception e) {
            // ignore
        }
    }
    
    public void evict(String... accountNumbers) {
        try {
            for (String acc : accountNumbers) {
                redis.delete("bank:account:" + acc);
            }
        } catch (Exception e) {
            // ignore
        }
    }
}
