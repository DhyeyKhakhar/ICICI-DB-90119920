package com.horizonbank.accounts.api;

import com.horizonbank.accounts.api.dto.AccountOpenRequest;
import com.horizonbank.accounts.api.dto.AccountOpenResponse;
import com.horizonbank.accounts.domain.BusinessException;
import com.horizonbank.accounts.domain.ErrorCode;
import com.horizonbank.accounts.service.AccountService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;

@RestController
@RequestMapping("/api/v1/accounts")
public class AccountController {

    private final AccountService accountService;

    public AccountController(AccountService accountService) {
        this.accountService = accountService;
    }

    @PostMapping
    public ResponseEntity<AccountOpenResponse> openAccount(@Valid @RequestBody AccountOpenRequest request) {
        LocalDate dob = request.customer().dateOfBirth();
        LocalDate today = LocalDate.now(ZoneId.of("Asia/Kolkata"));
        if (ChronoUnit.YEARS.between(dob, today) < 18) {
            throw new BusinessException(ErrorCode.VALIDATION_ERROR, "Customer must be at least 18 years old");
        }
        
        AccountOpenResponse response = accountService.open(request);
        return ResponseEntity.created(URI.create("/api/v1/accounts/" + response.accountNumber())).body(response);
    }

    @GetMapping("/{accountNumber}")
    public ResponseEntity<AccountOpenResponse> getAccount(@PathVariable String accountNumber) {
        if (accountNumber == null || accountNumber.length() != 12) {
            throw new BusinessException(ErrorCode.VALIDATION_ERROR, "accountNumber must be 12 digits");
        }
        var result = accountService.get(accountNumber);
        return ResponseEntity.ok()
                .header("X-Cache", result.cached() ? "HIT" : "MISS")
                .body(result.response());
    }
}
