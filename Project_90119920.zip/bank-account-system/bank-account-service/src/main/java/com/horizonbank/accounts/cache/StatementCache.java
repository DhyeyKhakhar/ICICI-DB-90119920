package com.horizonbank.accounts.cache;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.horizonbank.accounts.api.dto.StatementResponse;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import java.time.Duration;

@Component
public class StatementCache {
    private final StringRedisTemplate redis;
    private final ObjectMapper mapper;

    public StatementCache(StringRedisTemplate redis, ObjectMapper mapper) {
        this.redis = redis;
        this.mapper = mapper;
    }

    public void bumpVersion(String accountNumber) {
        try {
            redis.opsForValue().increment("bank:stmt-ver:" + accountNumber);
        } catch (Exception e) {}
    }

    private String getVersion(String accountNumber) {
        try {
            String v = redis.opsForValue().get("bank:stmt-ver:" + accountNumber);
            return v == null ? "0" : v;
        } catch (Exception e) {
            return "0";
        }
    }

    public StatementResponse get(String accountNumber, String fromDate, String toDate, int page, int size) {
        try {
            String v = getVersion(accountNumber);
            String key = String.format("bank:stmt:%s:v%s:%s:%s:%d:%d", accountNumber, v, fromDate, toDate, page, size);
            String json = redis.opsForValue().get(key);
            if (json == null) return null;
            return mapper.readValue(json, StatementResponse.class);
        } catch (Exception e) {
            return null;
        }
    }

    public void put(String accountNumber, String fromDate, String toDate, int page, int size, StatementResponse res) {
        try {
            String v = getVersion(accountNumber);
            String key = String.format("bank:stmt:%s:v%s:%s:%s:%d:%d", accountNumber, v, fromDate, toDate, page, size);
            redis.opsForValue().set(key, mapper.writeValueAsString(res), Duration.ofMinutes(5));
        } catch (Exception e) {}
    }
}
