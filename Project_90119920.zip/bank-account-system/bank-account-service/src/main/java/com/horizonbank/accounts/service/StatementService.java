package com.horizonbank.accounts.service;

import com.horizonbank.accounts.api.dto.StatementResponse;
import com.horizonbank.accounts.api.dto.TransactionDTO;
import com.horizonbank.accounts.cache.StatementCache;
import com.horizonbank.accounts.domain.BusinessException;
import com.horizonbank.accounts.domain.ErrorCode;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
public class StatementService {
    private final JdbcClient jdbc;
    private final StatementCache cache;
    private static final ZoneId IST = ZoneId.of("Asia/Kolkata");
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ssXXX");

    public StatementService(JdbcClient jdbc, StatementCache cache) {
        this.jdbc = jdbc;
        this.cache = cache;
    }

    public record StatementResult(StatementResponse response, boolean cached) {}

    @Transactional(readOnly = true)
    public StatementResult getStatement(String accountNumber, String fromDate, String toDate, int page, int size) {
        StatementResponse cached = cache.get(accountNumber, fromDate, toDate, page, size);
        if (cached != null) return new StatementResult(cached, true);

        Long accId = jdbc.sql("SELECT account_id FROM account WHERE account_number = ?")
                .param(accountNumber).query(Long.class).optional()
                .orElseThrow(() -> new BusinessException(ErrorCode.ACCOUNT_NOT_FOUND));

        String customerName = jdbc.sql("SELECT c.full_name FROM account a JOIN customer c USING (customer_id) WHERE a.account_id = ?")
                .param(accId).query(String.class).single();

        OffsetDateTime fromTs = LocalDate.parse(fromDate).atStartOfDay(IST).toOffsetDateTime();
        OffsetDateTime toTs = LocalDate.parse(toDate).plusDays(1).atStartOfDay(IST).toOffsetDateTime();

        List<TransactionDTO> txns = jdbc.sql("""
                SELECT t.txn_id, t.txn_time, t.txn_type, t.amount, t.balance_after, t.description, ft.reference_no
                FROM account_transaction t
                LEFT JOIN fund_transfer ft ON ft.transfer_id = t.transfer_id
                WHERE t.account_id = :accId AND t.txn_time >= :fromTs AND t.txn_time < :toTs
                ORDER BY t.txn_time DESC, t.txn_id DESC
                LIMIT :size OFFSET :offset""")
                .param("accId", accId).param("fromTs", fromTs).param("toTs", toTs)
                .param("size", size).param("offset", page * size)
                .query((rs, n) -> new TransactionDTO(
                        rs.getLong("txn_id"),
                        FMT.format(rs.getObject("txn_time", OffsetDateTime.class)),
                        rs.getString("txn_type"),
                        rs.getBigDecimal("amount").toPlainString(),
                        rs.getBigDecimal("balance_after").toPlainString(),
                        rs.getString("description"),
                        rs.getString("reference_no")
                )).list();

        var totals = jdbc.sql("""
                SELECT count(*) AS total_elements,
                       ceil(count(*)::numeric / :size) AS total_pages,
                       COALESCE(SUM(amount) FILTER (WHERE txn_type = 'CREDIT'), 0) AS total_credits,
                       COALESCE(SUM(amount) FILTER (WHERE txn_type = 'DEBIT'), 0) AS total_debits
                FROM account_transaction
                WHERE account_id = :accId AND txn_time >= :fromTs AND txn_time < :toTs""")
                .param("size", size).param("accId", accId).param("fromTs", fromTs).param("toTs", toTs)
                .query((rs, n) -> new Object[]{
                        rs.getLong("total_elements"), rs.getInt("total_pages"),
                        rs.getBigDecimal("total_credits"), rs.getBigDecimal("total_debits")
                }).single();

        BigDecimal opening = jdbc.sql("""
                SELECT COALESCE((SELECT balance_after FROM account_transaction
                WHERE account_id = :accId AND txn_time < :fromTs
                ORDER BY txn_time DESC, txn_id DESC LIMIT 1), 0.00)""")
                .param("accId", accId).param("fromTs", fromTs)
                .query(BigDecimal.class).single();

        BigDecimal closing = jdbc.sql("""
                SELECT COALESCE((SELECT balance_after FROM account_transaction
                WHERE account_id = :accId AND txn_time < :toTs
                ORDER BY txn_time DESC, txn_id DESC LIMIT 1), 0.00)""")
                .param("accId", accId).param("toTs", toTs)
                .query(BigDecimal.class).single();

        StatementResponse response = new StatementResponse(
                accountNumber, customerName, "INR", fromDate, toDate,
                opening.toPlainString(), closing.toPlainString(),
                ((BigDecimal) totals[2]).toPlainString(), ((BigDecimal) totals[3]).toPlainString(),
                page, size, (long) totals[0], (int) totals[1], txns
        );

        cache.put(accountNumber, fromDate, toDate, page, size, response);
        return new StatementResult(response, false);
    }
}
