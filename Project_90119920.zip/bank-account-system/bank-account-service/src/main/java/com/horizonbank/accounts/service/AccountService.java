package com.horizonbank.accounts.service;

import com.horizonbank.accounts.api.dto.AccountOpenRequest;
import com.horizonbank.accounts.api.dto.AccountOpenResponse;
import com.horizonbank.accounts.cache.AccountCache;
import com.horizonbank.accounts.domain.BusinessException;
import com.horizonbank.accounts.domain.ErrorCode;
import com.horizonbank.accounts.events.EventPublisher;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

@Service
public class AccountService {

    private final JdbcClient jdbc;
    private final EventPublisher publisher;
    private final AccountCache cache;

    public AccountService(JdbcClient jdbc, EventPublisher publisher, AccountCache cache) {
        this.jdbc = jdbc;
        this.publisher = publisher;
        this.cache = cache;
    }

    @Transactional
    public AccountOpenResponse open(AccountOpenRequest req) {
        BigDecimal initialDeposit = new BigDecimal(req.initialDeposit());
        if (req.accountType().equals("SAVINGS") && initialDeposit.compareTo(new BigDecimal("1000.00")) < 0) {
            throw new BusinessException(ErrorCode.VALIDATION_ERROR, "Initial deposit below minimum");
        }
        if (req.accountType().equals("CURRENT") && initialDeposit.compareTo(new BigDecimal("5000.00")) < 0) {
            throw new BusinessException(ErrorCode.VALIDATION_ERROR, "Initial deposit below minimum");
        }
        if (initialDeposit.compareTo(new BigDecimal("1000000.00")) > 0) {
            throw new BusinessException(ErrorCode.VALIDATION_ERROR, "Initial deposit above maximum");
        }

        try {
            Long customerId = jdbc.sql("SELECT customer_id FROM customer WHERE pan = ?")
                    .param(req.customer().pan().toUpperCase())
                    .query(Long.class).optional().orElse(null);
            
            boolean newCustomer = false;
            if (customerId == null) {
                newCustomer = true;
                customerId = jdbc.sql("INSERT INTO customer (full_name, email, phone, date_of_birth, pan) VALUES (?, ?, ?, ?, ?) RETURNING customer_id")
                        .param(req.customer().fullName())
                        .param(req.customer().email().toLowerCase())
                        .param(req.customer().phone())
                        .param(req.customer().dateOfBirth())
                        .param(req.customer().pan().toUpperCase())
                        .query(Long.class).single();
            }

            var accountRow = jdbc.sql("INSERT INTO account (customer_id, account_type, balance) VALUES (?, ?, ?) RETURNING account_id, account_number, opened_at")
                    .param(customerId)
                    .param(req.accountType())
                    .param(initialDeposit)
                    .query((rs, rowNum) -> new Object[]{rs.getLong(1), rs.getString(2), rs.getObject(3, OffsetDateTime.class)})
                    .single();
            
            long accountId = (long) accountRow[0];
            String accountNumber = (String) accountRow[1];
            OffsetDateTime openedAt = (OffsetDateTime) accountRow[2];

            jdbc.sql("INSERT INTO account_transaction (account_id, txn_type, amount, balance_after, description) VALUES (?, 'CREDIT', ?, ?, 'Initial deposit')")
                    .param(accountId)
                    .param(initialDeposit)
                    .param(initialDeposit)
                    .update();

            AccountOpenResponse resp = new AccountOpenResponse(
                    accountNumber, customerId, req.customer().fullName(), newCustomer, req.accountType(), "INR", initialDeposit.toPlainString(), "ACTIVE", openedAt
            );

            publisher.accountOpened(accountNumber, customerId, req.customer(), req.accountType(), initialDeposit.toPlainString());
            return resp;

        } catch (DataIntegrityViolationException e) {
            String msg = e.getMessage() != null ? e.getMessage() : "";
            if (msg.contains("uq_account_customer_type")) {
                throw new BusinessException(ErrorCode.DUPLICATE_ACCOUNT_TYPE);
            }
            if (msg.contains("uq_customer_email") || msg.contains("uq_customer_phone")) {
                throw new BusinessException(ErrorCode.CUSTOMER_CONFLICT);
            }
            throw e;
        }
    }

    public AccountResult get(String accountNumber) {
        AccountOpenResponse cached = cache.get(accountNumber);
        if (cached != null) {
            return new AccountResult(cached, true);
        }
        AccountOpenResponse db = getFromDb(accountNumber);
        cache.put(accountNumber, db);
        return new AccountResult(db, false);
    }
    
    private AccountOpenResponse getFromDb(String accountNumber) {
        return jdbc.sql("SELECT a.account_number, c.customer_id, c.full_name, a.account_type, a.currency, a.balance, a.status, a.opened_at FROM account a JOIN customer c USING (customer_id) WHERE a.account_number = ?")
                .param(accountNumber)
                .query((rs, n) -> new AccountOpenResponse(
                        rs.getString("account_number"),
                        rs.getLong("customer_id"),
                        rs.getString("full_name"),
                        false,
                        rs.getString("account_type"),
                        rs.getString("currency"),
                        rs.getBigDecimal("balance").toPlainString(),
                        rs.getString("status"),
                        rs.getObject("opened_at", OffsetDateTime.class)
                )).optional().orElseThrow(() -> new BusinessException(ErrorCode.ACCOUNT_NOT_FOUND));
    }
}
