package com.horizonbank.accounts.notification;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
public class NotificationConsumer {

    private static final Logger log = LoggerFactory.getLogger(NotificationConsumer.class);
    private final ObjectMapper mapper;
    private final JdbcClient jdbc;

    public NotificationConsumer(ObjectMapper mapper, JdbcClient jdbc) {
        this.mapper = mapper;
        this.jdbc = jdbc;
    }

    @KafkaListener(topics = {"bank.account.opened.v1", "bank.transfer.completed.v1"}, groupId = "notification-service")
    public void onEvent(String json) {
        JsonNode e;
        try {
            e = mapper.readTree(json);
        } catch (Exception poison) {
            log.error("Unparseable event skipped: {}", json);
            return;
        }

        UUID eventId = UUID.fromString(e.get("eventId").asText());
        JsonNode d = e.get("data");

        switch (e.get("eventType").asText()) {
            case "TransferCompleted" -> {
                save(eventId, d.get("fromAccountNumber").asText(), "TransferCompleted",
                        String.format("Rs %s debited from A/c %s to A/c %s. Ref %s. Avl bal Rs %s",
                                d.get("amount").asText(), mask(d.get("fromAccountNumber").asText()),
                                mask(d.get("toAccountNumber").asText()), d.get("referenceNo").asText(),
                                d.get("fromBalanceAfter").asText()));

                save(eventId, d.get("toAccountNumber").asText(), "TransferCompleted",
                        String.format("Rs %s credited to A/c %s from A/c %s. Ref %s. Avl bal Rs %s",
                                d.get("amount").asText(), mask(d.get("toAccountNumber").asText()),
                                mask(d.get("fromAccountNumber").asText()), d.get("referenceNo").asText(),
                                d.get("toBalanceAfter").asText()));
            }
            case "AccountOpened" -> save(eventId, d.get("accountNumber").asText(), "AccountOpened",
                    String.format("Welcome to Horizon Bank. Your %s A/c %s is open. Bal Rs %s",
                            d.get("accountType").asText(), mask(d.get("accountNumber").asText()),
                            d.get("initialDeposit").asText()));
            default -> log.warn("Unknown eventType {} skipped", e.get("eventType").asText());
        }
    }

    private void save(UUID eventId, String accountNumber, String type, String message) {
        jdbc.sql("""
                INSERT INTO notification_log (event_id, account_number, event_type, message)
                VALUES (:id, :acc, :type, :msg)
                ON CONFLICT (event_id, account_number) DO NOTHING""")
                .param("id", eventId)
                .param("acc", accountNumber)
                .param("type", type)
                .param("msg", message)
                .update();
    }

    private static String mask(String accountNumber) {
        return "XX" + accountNumber.substring(accountNumber.length() - 4);
    }
}
