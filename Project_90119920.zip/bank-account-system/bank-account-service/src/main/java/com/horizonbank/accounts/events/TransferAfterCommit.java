package com.horizonbank.accounts.events;

import com.horizonbank.accounts.cache.AccountCache;
import com.horizonbank.accounts.cache.StatementCache;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;

@Component
public class TransferAfterCommit {
    private final AccountCache cache;
    private final StatementCache stmtCache;
    private final EventPublisher publisher;

    public TransferAfterCommit(AccountCache cache, StatementCache stmtCache, EventPublisher publisher) {
        this.cache = cache;
        this.stmtCache = stmtCache;
        this.publisher = publisher;
    }

    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
    public void on(TransferCommitted e) {
        var r = e.result();
        cache.evict(r.fromAccountNumber(), r.toAccountNumber());
        stmtCache.bumpVersion(r.fromAccountNumber());
        stmtCache.bumpVersion(r.toAccountNumber());
        publisher.transferCompleted(r);
    }
}
