package com.horizonbank.accounts.service;

import com.horizonbank.accounts.api.dto.TransferResponse;

public record IdempotentResult(TransferResponse response, boolean replayed) {}
