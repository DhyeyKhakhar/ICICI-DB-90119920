package com.horizonbank.accounts.service;
import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.UUID;
public record TransferResult(
        UUID transferId, String referenceNo, OffsetDateTime createdAt,
        String fromAccountNumber, String toAccountNumber, BigDecimal amount,
        String remarks, BigDecimal fromBalanceAfter, BigDecimal toBalanceAfter) {}
