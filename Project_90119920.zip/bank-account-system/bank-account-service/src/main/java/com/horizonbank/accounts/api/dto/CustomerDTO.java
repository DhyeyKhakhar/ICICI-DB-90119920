package com.horizonbank.accounts.api.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;

public record CustomerDTO(
    @NotBlank
    @Size(min = 3, max = 100)
    @Pattern(regexp = "^[a-zA-Z .']+$")
    String fullName,

    @NotBlank
    @Email
    @Size(max = 150)
    String email,

    @NotBlank
    @Pattern(regexp = "^[6-9][0-9]{9}$")
    String phone,

    @NotNull
    LocalDate dateOfBirth,

    @NotBlank
    @Pattern(regexp = "^[a-zA-Z]{5}[0-9]{4}[a-zA-Z]$")
    String pan
) {}
