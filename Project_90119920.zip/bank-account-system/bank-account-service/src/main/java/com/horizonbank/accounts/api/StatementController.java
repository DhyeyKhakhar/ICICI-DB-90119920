package com.horizonbank.accounts.api;

import com.horizonbank.accounts.api.dto.StatementResponse;
import com.horizonbank.accounts.domain.BusinessException;
import com.horizonbank.accounts.domain.ErrorCode;
import com.horizonbank.accounts.service.StatementService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;

@RestController
@RequestMapping("/api/v1")
public class StatementController {

    private final StatementService statementService;

    public StatementController(StatementService statementService) {
        this.statementService = statementService;
    }

    @GetMapping("/accounts/{accountNumber}/statement")
    public ResponseEntity<StatementResponse> getStatement(
            @PathVariable String accountNumber,
            @RequestParam(required = false) String fromDate,
            @RequestParam(required = false) String toDate,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {

        if (accountNumber == null || accountNumber.length() != 12) {
            throw new BusinessException(ErrorCode.VALIDATION_ERROR, "accountNumber must be 12 digits");
        }
        if (page < 0 || size < 1 || size > 100) {
            throw new BusinessException(ErrorCode.VALIDATION_ERROR, "Invalid page or size");
        }

        LocalDate to = toDate != null ? parseDate(toDate) : LocalDate.now(ZoneId.of("Asia/Kolkata"));
        LocalDate from = fromDate != null ? parseDate(fromDate) : to.minusDays(29);

        if (to.isAfter(LocalDate.now(ZoneId.of("Asia/Kolkata")))) {
            throw new BusinessException(ErrorCode.VALIDATION_ERROR, "toDate cannot be in the future");
        }
        if (from.isAfter(to)) {
            throw new BusinessException(ErrorCode.VALIDATION_ERROR, "fromDate cannot be after toDate");
        }
        if (ChronoUnit.DAYS.between(from, to) > 90) { // 90 days maximum range
            throw new BusinessException(ErrorCode.VALIDATION_ERROR, "Date range cannot exceed 90 days");
        }

        var result = statementService.getStatement(accountNumber, from.toString(), to.toString(), page, size);
        return ResponseEntity.ok()
                .header("X-Cache", result.cached() ? "HIT" : "MISS")
                .body(result.response());
    }

    private LocalDate parseDate(String dateStr) {
        try {
            return LocalDate.parse(dateStr);
        } catch (DateTimeParseException e) {
            throw new BusinessException(ErrorCode.VALIDATION_ERROR, "Invalid date format");
        }
    }
}
