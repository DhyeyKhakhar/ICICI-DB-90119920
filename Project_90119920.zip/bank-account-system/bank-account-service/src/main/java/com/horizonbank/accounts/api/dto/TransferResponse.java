package com.horizonbank.accounts.api.dto;

import java.time.OffsetDateTime;

public record TransferResponse(
    String transferId,
    String referenceNo,
    String status,
    String fromAccountNumber,
    String toAccountNumber,
    String amount,
    String currency,
    String remarks,
    String fromBalanceAfter,
    OffsetDateTime createdAt
) {}
